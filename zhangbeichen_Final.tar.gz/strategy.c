#include<stdio.h>
void graph(int a[15][15]);
void kaiju(int a[15][15],char begin1,int begin2);
void compare(int c[15][15],int d[8]);
void score(int b1[15][15][6],int b2[15][15][6],int c[15][15],int con);
void search2(int a[15][15],int b1[15][15][6],int k);
void search1(int a[15][15],int k,int c,int h);
void strategy(int a[15][15],int d[8],int con);
void strategy(int a[15][15],int d[8],int con)
{
	int g3[4][4][8],g1[8],i,j,h,g2[4][8],b1[15][15][6],b2[15][15][6];
	int c[15][15],c1[4][4][4];
	for(i=0;i<=3;i++)
	{
		for(j=0;j<=3;j++)
		{
			for(h=0;h<=3;h++)
			c1[i][j][h]=0;
		}
	}
	search2(a,b1,1);
	search2(a,b1,-1);
	score(b1,b2,c,con);
	compare(c,g1);
	for(i=0;i<=3;i++)
	{
		a[g1[2*i]][g1[2*i+1]]=con;
		search2(a,b1,1);
		search2(a,b1,-1);
		score(b1,b2,c,(-1)*con);
		compare(c,g2[i]);
		for(j=0;j<=4;j++)
		{
			a[g2[i][2*j]][g2[i][2*j+1]]=(-1)*con;
			search2(a,b1,1);
			search2(a,b1,-1);
			score(b1,b2,c,con);
			compare(c,g3[i][j]);
			for(h=0;h<=4;h++)
			{
				a[g3[i][j][2*h]][g3[i][j][2*h+1]]=con;
				search1(a,con,c1[i][j][h],con);
				search1(a,(-1)*con,c1[i][j][h],con);
				a[g3[i][j][2*h]][g3[i][j][2*h+1]]=0;
			}
			a[g2[i][2*j]][g2[i][2*j+1]]=0;
		}
		a[g1[2*i]][g1[2*i+1]]=0;
	}
	for(i=0;i<=3;i++)
	{
		for(j=0;j<=3;j++)
		{
			for(h=1;h<=3;h++)
			{
				if(c1[i][j][0]<c1[i][j][i])
					c1[i][j][0]=c1[i][j][i];
			}
			if(c1[i][0][0]>=c1[i][j][0])
				c1[i][0][0]=c1[i][j][0];
		}
	}
	j=0;
	for(i=0;i<=3;i++)
	{
		if(c1[i][0][0]>c1[j][0][0])
		j=i;
	}
	d[0]=g1[2*j];
	d[1]=g1[2*j+1];
}
