#include<stdio.h>
void kaiju(int a[15][15],char begin1,int begin2)
{
	if(begin1=='d')
		{
			a[7][7]=1;a[8][7]=-1;
			if(begin2==1)
			{
				a[9][7]=1;
			}
			else if(begin2==2)
			{
				a[9][8]=1;
			}
			else if(begin2==3)
			{
				a[9][9]=1;
			}
			else if(begin2==4)
			{
				a[8][8]=1;
			}
			else if(begin2==5)
			{
				a[8][9]=1;
			}
			else if(begin2==6)
			{
				a[7][8]=1;
			}
			else if(begin2==7)
			{
				a[7][9]=1;
			}
			else if(begin2==8)
			{
				a[6][7]=1;
			}
			else if(begin2==9)
			{
				a[6][8]=1;
			}
			else if(begin2==10)
			{
				a[6][9]=1;
			}
			else if(begin2==11)
			{
				a[5][7]=1;
			}
			else if(begin2==12)
			{
				a[5][8]=1;
			}
			else if(begin2==13)
			{
				a[5][9]=1;
			}
		}
		else if(begin1=='i')
		{
			a[7][7]=1;a[8][8]=-1;
			if(begin2==1)
			{
				a[9][9]=1;
			}
			else if(begin2==2)
			{
				a[8][9]=1;
			}
			else if(begin2==3)
			{
				a[7][9]=1;
			}
			else if(begin2==4)
			{
				a[6][9]=1;
			}
			else if(begin2==5)
			{
				a[5][9]=1;
			}
			else if(begin2==6)
			{
				a[7][8]=1;
			}
			else if(begin2==7)
			{
				a[6][8]=1;
			}
			else if(begin2==8)
			{
				a[5][8]=1;
			}
			else if(begin2==9)
			{
				a[6][7]=1;
			}
			else if(begin2==10)
			{
				a[5][7]=1;
			}
			else if(begin2==11)
			{
				a[6][6]=1;
			}
			else if(begin2==12)
			{
				a[5][6]=1;
			}
			else if(begin2==13)
			{
				a[5][5]=1;
			}
		} 
}
