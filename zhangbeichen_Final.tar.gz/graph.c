#include<stdio.h>
void graph(int a[15][15])
{
	system("clear");
	int i,j;
	printf("welcome to polaris's wuziqi game\n");
	printf("15");
	for(i=14;i>=0;i--)
	{
		if(a[14][i]==0&&i==0)
		printf("━┓");
		else if(a[14][i]==0&&i==14)
		printf("┏");
		else if(a[14][i]==1&&i==14)
		printf("○");
		else if(a[14][i]==-1&&i==14)
		printf("●");
		else if(a[14][i]==1)
		printf("━○");
		else if(a[14][i]==-1)
		printf("━●");
		else if(a[14][i]==0&&i!=14&&i!=0)
		printf("━┯");
	}
	for(i=13;i>=1;i--)
	{
		printf("\n%2d",i+1);
		for(j=0;j<=14;j++)
		{
			if(a[i][j]==0&&j==0)
			printf("┠");
			else if(a[i][j]==0&&j==14)
			printf("─┨");
			else if(a[i][j]==1&&j==0)
			printf("○");
			else if(a[i][j]==-1&&j==0)
			printf("●");
			else if(a[i][j]==1)
			printf("─○");
			else if(a[i][j]==-1)
			printf("─●");
			else if(a[i][j]==0&&j!=14&&j!=0)
			printf("─┼");
		}
	}
	printf("\n%2d",1);
	for(i=0;i<=14;i++)
	{
		if(a[0][i]==0&&i==0)
		printf("┗");
		else if(a[0][i]==0&&i==14)
		printf("━┛");
		else if(a[0][i]==1&&i==0)
		printf("○");
		else if(a[0][i]==-1&&i==0)
		printf("●");
		else if(a[0][i]==1)
		printf("━○");
		else if(a[0][i]==-1)
		printf("━●");
		else if(a[0][i]==0&&i!=14&&i!=0)
		printf("━┷");
	}
	printf("\n  A B C D E F G H I J K L M N O\n");
}
