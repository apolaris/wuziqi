#include<stdio.h>/*this code is owned by beichenzhang*/
#include <time.h>
void graph(int a[15][15]);
int judge1(int a[15][15]);
void kaiju(int a[15][15],char begin1,int begin2);
int judge(int a[15][15],int l);
void compare(int c[15][15],int d[8]);
void score(int b1[15][15][6],int b2[15][15][6],int c[15][15],int con);
void search2(int a[15][15],int b1[15][15][6],int k);
void jinshou(int a[15][15],int js[15][15]);
void score2(int b1[15][15][6],int b2[15][15][6],int js[15][15],int c[15][15],int con);
void search1(int a[15][15],int b1[15][15][6],int k);
main(int argc,char *argv[])
{
	clock_t startb,betb;/*clock for black*/
	clock_t startw,betw;/*clock for white*/
	float tb,tw,temp;
	tb=tw=0;
	char begin1,y;/*the 26 kinds of starting*/
	int a[15][15];/*the chess is reserved therein*/
	int begin2,j,i,open,con,x;/*con means who turned to*/
	FILE *fp;
	char yg[4];
	//time_t t;
	//struct tm *local;
	//time(&t);
	//local=localtime(&t);//write the time into the file
	char *name;
	for(i=0;i<=14;i++)/*array chu shi hua*/
	{
		for(j=0;j<=14;j++)
		{
			a[i][j]=0;
		}
	}
	graph(a);
	con=1;
	if(*argv[1]=='r'&&*(argv[1]+1)=='j') 
	{
		int x1,js[15][15];
		char y1;
		if(argc==3)
		{
			name=argv[2];
		}
		else
		name="zbc";
		fp=fopen(name,"w");
		startb = clock();
		open=getchar();
		if(open=='z')
		{
			scanf("%c%d",&begin1,&begin2);
			getchar();
			tb=((betb=clock())-startb)/10;
			printf("black's time:%.1fs\nwhite's time:0.0s\n",tb);
			kaiju(a,begin1,begin2);
			graph(a);
			fprintf(fp,"%c%c%d\n",open,begin1,begin2);			
			con=(-1)*con;
			startw = clock();
		}
		else
		{
			scanf("%d",&x);
			fprintf(fp,"%c%d\n",open,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][open-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:0.0s\n",tb);
			startw = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tw=((betw=clock())-startw)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startb = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startw = clock();
		}
		//begin jiaohuan
		scanf("%s",yg);
		getchar();
		y=yg[0];
		if(yg[2]>='0'&&yg[2]<='9')
			x=10*(yg[1]-'0')+yg[2]-'0';
		else
			x=yg[1]-'0';
		if(yg[0]=='h'&&yg[1]=='h')
		{
			temp=tb;
			tb=tw;
			tw=temp;
			printf("black and white have changed\nblack's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startw = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tw=((betw=clock())-startw)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		else
		{
			fprintf(fp,"%c%d\n",y,x);
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		startb = clock();
		begin1=getchar();
		if(begin1=='w')
		{
			scanf("%c%d %c%d",&y,&x,&y1,&x1);
			getchar();
			tb=((betb=clock())-startb)/10;
			scanf("%d",&i);
			getchar();
			if(i==1)
			{
				a[x-1][y-'a']=con;
				fprintf(fp,"%c%d\n",y,x);
			}
			else if(i==2)
			{
				a[x1-1][y1-'a']=con;
				fprintf(fp,"%c%d\n",y1,x1);
			}
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		else
		{
			scanf("%d",&x);
			fprintf(fp,"%c%d\n",begin1,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][begin1-'a']=con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		x1=0;
		while(x1==0)
		{
			con=(-1)*con;
			if(con==1)
			{	
				jinshou(a,js);
				startb = clock();
				scanf("%c%d",&y,&x);
				fprintf(fp,"%c%d\n",y,x);
				getchar();
				tb=((betb=clock())-startb)/10;
				a[x-1][y-'a']=con;
				graph(a);
				printf("\nthe last chess is %c%d\n",y,x);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
				x1=judge3(a);
				x1+=wjr(js,x-1,y-'a');
			}
			else if(con==-1)
			{
				startw = clock();
				scanf("%c%d",&y,&x);
				fprintf(fp,"%c%d\n",y,x);
				getchar();
				tw=((betw=clock())-startw)/10;
				a[x-1][y-'a']=con;
				graph(a);
				printf("\nthe last chess is %c%d\n",y,x);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
				x1=judge2(a);
			}
		}
		if(x1<0)
			printf("\nblack is winner");
		else if(x1>0)
			printf("\nwhite is winner");
		//fprintf(fp,"%d骞?d鏈?d鏃?d鐐?d鍒哱n",
		//local->tm_year+1900,local->tm_mon+1,local->tm_mday;
		//local->tm_hour,local->tm_min);
		fclose(fp);
	}
	else if(*argv[1]=='r')
	{
		int x1;char y1;
		if(argc==3)
		{
			name=argv[2];
		}
		else
		name="zbc";
		fp=fopen(name,"w");
		startb = clock();
		open=getchar();
		if(open=='z')
		{
			scanf("%c%d",&begin1,&begin2);
			getchar();
			tb=((betb=clock())-startb)/10;
			printf("black's time:%.1fs\nwhite's time:0.0s\n",tb);
			kaiju(a,begin1,begin2);
			graph(a);
			fprintf(fp,"%c%c%d\n",open,begin1,begin2);			
			con=(-1)*con;
			startw = clock();
		}
		else
		{
			scanf("%d",&x);
			fprintf(fp,"%c%d\n",open,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][open-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:0.0s\n",tb);
			startw = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tw=((betw=clock())-startw)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startb = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startw = clock();
		}
		//begin jiaohuan
		scanf("%s",yg);
		getchar();
		y=yg[0];
		if(yg[2]>='0'&&yg[2]<='9')
			x=10*(yg[1]-'0')+yg[2]-'0';
		else
			x=yg[1]-'0';
		if(yg[0]=='h'&&yg[1]=='h')
		{
			temp=tb;
			tb=tw;
			tw=temp;
			printf("black and white have changed\nblack's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startw = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tw=((betw=clock())-startw)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		else
		{
			fprintf(fp,"%c%d\n",y,x);
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		startb = clock();
		begin1=getchar();
		if(begin1=='w')
		{
			scanf("%c%d %c%d",&y,&x,&y1,&x1);
			getchar();
			tb=((betb=clock())-startb)/10;
			scanf("%d",&i);
			getchar();
			if(i==1)
			{
				a[x-1][y-'a']=con;
				fprintf(fp,"%c%d\n",y,x);
			}
			else if(i==2)
			{
				a[x1-1][y1-'a']=con;
				fprintf(fp,"%c%d\n",y1,x1);
			}
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		else
		{
			scanf("%d",&x);
			fprintf(fp,"%c%d\n",begin1,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][begin1-'a']=con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		x1=0;
		while(x1==0)
		{
			con=(-1)*con;
			if(con==1)
			{
				startb = clock();
				scanf("%c%d",&y,&x);
				fprintf(fp,"%c%d\n",y,x);
				getchar();
				tb=((betb=clock())-startb)/10;
				a[x-1][y-'a']=con;
				printf("\nthe last chess is %c%d\n",y,x);
				graph(a);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
				x1=judge3(a);
			}
			else if(con==-1)
			{
				startw = clock();
				scanf("%c%d",&y,&x);
				fprintf(fp,"%c%d\n",y,x);
				getchar();
				tw=((betw=clock())-startw)/10;
				a[x-1][y-'a']=con;
				graph(a);
				printf("\nthe last chess is %c%d\n",y,x);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
				x1=judge2(a);
			}
		}
		if(x1<0)
			printf("\nblack is winner");
		else if(x1>0)
			printf("\nwhite is winner");
		//fprintf(fp,"%d骞?d鏈?d鏃?d鐐?d鍒哱n",
		//local->tm_year+1900,local->tm_mon+1,local->tm_mday;
		//local->tm_hour,local->tm_min);
		fclose(fp);
	}
	//jinshou for w   
	else if(*argv[1]=='j'&&*(argv[1]+1)=='w'&&*(argv[1]+2)=='j'&&argc!=4)
	{
		int b1[15][15][6],b2[15][15][6],c[15][15],d[8],js[15][15];
		int x1;char y1;
		con=-1;
		if(argc==3)
		{
			name=argv[2];
		}
		else
			name="zbc";
		fp=fopen(name,"w");
		startb = clock();
		kaiju(a,'i',4);
		tb=((betb=clock())-startb)/10;
		graph(a);
		printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		fprintf(fp,"zi4\n");
		startw = clock();
		scanf("%s",yg);
		getchar();
		y=yg[0];
		if(yg[2]>='0'&&yg[2]<='9')
			x=10*(yg[1]-'0')+yg[2]-'0';
		else
			x=yg[1]-'0';
		if(yg[0]=='h'&&yg[1]=='h')
		{
			fprintf(fp,"hh");
			temp=tb;
			tb=tw;
			tw=temp;
			printf("black and white have changed\nblack's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startw = clock();
			jinshou(a,js);
			search2(a,b1,1);
			search2(a,b2,-1);
			score2(b1,b2,js,c,con);
			compare(c,d);
			a[d[0]][d[1]]=con;
			printf("%d%d\n",d[0],d[1]);
			tw=((betw=clock())-startw)/10;
			y=d[1]+'a';
			fprintf(fp,"%c%d\n",y,d[0]+1);
			graph(a);
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			con=(-1)*con;
			startb = clock();
			begin1=getchar();
			if(begin1=='w')
			{
				scanf("%c%d %c%d",&y,&x,&y1,&x1);
				tb=((betb=clock())-startb)/10;
				getchar();
				a[x1-1][y1-'a']=con;
				fprintf(fp,"%c%d\n",y1,x1);
				graph(a);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			}
			else
			{
				scanf("%d",&x);
				fprintf(fp,"%c%d\n",begin1,x);
				getchar();
				tb=((betb=clock())-startb)/10;
				a[x-1][begin1-'a']=con;
				graph(a);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			}
			x1=0;
			while(x1==0)
			{
				con=(-1)*con;
				startw = clock();
				jinshou(a,js);
				search1(a,b1,1);
				search1(a,b2,-1);
				score2(b1,b2,js,c,con);
				compare(c,d);
				if(c[d[0]][d[1]]>=0)
				{
					a[d[0]][d[1]]=con;
					tw=((betw=clock())-startw)/10;
					y=d[1]+'a';
					fprintf(fp,"%c%d\n",y,d[0]+1);
					graph(a);
					printf("\nthe last chess is %c%d\n",y,d[0]+1);
					printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
					x1=judge2(a);
				}
				if(x1==0)
				{
					con=(-1)*con;
					jinshou(a,js);
					startb = clock();
					scanf("%c%d",&y,&x);
					fprintf(fp,"%c%d\n",y,x);
					getchar();
					tb=((betb=clock())-startb)/10;
					a[x-1][y-'a']=con;
					graph(a);
					printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
					x1=judge3(a);
					
					x1+=wjr(js,x-1,y-'a');
				}
			}
		}
		else
		{
			fprintf(fp,"%c%d\n",y,x);
			a[(x-1)][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startb = clock();
			jinshou(a,js);
			search1(a,b1,con);
			search1(a,b2,(-1)*con);
			score2(b1,b2,js,c,con);
			compare(c,d);
			if(*(argv[1]+3)=='1')
			{
				printf("w%c%d %c%d\n",d[1]+'a',d[0]+1,d[3]+'a',d[2]+1);
				scanf("%d",&x);
				getchar();
				if(x==2)
					d[0]=d[2];d[1]=d[3];
			}
			a[d[0]][d[1]]=con;
			tb=((betb=clock())-startb)/10;
			graph(a);
			y=d[1]+'a';
			fprintf(fp,"%c%d\n",y,d[0]+1);
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			x1=0;
			while(x1==0)
			{
				con=(-1)*con;
				startw = clock();
				scanf("%c%d",&y,&x);
				getchar();
				fprintf(fp,"%c%d\n",y,x);
				tw=((betw=clock())-startw)/10;
				a[x-1][y-'a']=con;
				graph(a);
				printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
				x1=judge2(a);
				if(x1==0)
				{
					con=(-1)*con;
					jinshou(a,js);
					search1(a,b1,con);
					search1(a,b2,(-1)*con);
					score2(b1,b2,js,c,con);
					compare(c,d);
					if(c[d[0]][d[1]]>=0)
					{
						a[d[0]][d[1]]=con;
						tw=((betw=clock())-startw)/10;
						y=d[1]+'a';
						fprintf(fp,"%c%d\n",y,d[0]+1);
						graph(a);
						printf("\nthe last chess is %c%d\n",y,d[0]+1);
						printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
						x1=judge3(a);
					}
					else
						printf("\npass\n");
						fprintf(fp,"%c%d\n",'h',20);
				}
			}
		}
		if(x1<0)
			printf("\nblack is winner");
		else if(x1>0)
			printf("\nwhite is winner");
		fclose(fp);
	}
	              
	else if(*argv[1]=='j'&&*(argv[1]+1)=='w'&&argc!=4)
	{
		int b1[15][15][6],b2[15][15][6],c[15][15],d[8];
		int x1;char y1;
		con=-1;
		if(argc==3)
		{
			name=argv[2];
		}
		else
			name="zbc";
		fp=fopen(name,"w");
		startb = clock();
		kaiju(a,'i',4);
		tb=((betb=clock())-startb)/10;
		graph(a);
		printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		fprintf(fp,"zi4\n");
		startw = clock();
		scanf("%s",yg);
		getchar();
		y=yg[0];
		if(yg[2]>='0'&&yg[2]<='9')
			x=10*(yg[1]-'0')+yg[2]-'0';
		else
			x=yg[1]-'0';
		if(yg[0]=='h'&&yg[1]=='h')
		{
			fprintf(fp,"hh");
			temp=tb;
			tb=tw;
			tw=temp;
			printf("black and white have changed\nblack's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startw = clock();
			search2(a,b1,1);
			search2(a,b2,-1);
			score(b1,b2,c,con);
			compare(c,d);
			a[d[0]][d[1]]=con;
			tw=((betw=clock())-startw)/10;
			y=d[1]+'a';
			fprintf(fp,"%c%d\n",y,d[0]+1);
			graph(a);
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			con=(-1)*con;
			startb = clock();
			begin1=getchar();
			if(begin1=='w')
			{
				scanf("%c%d %c%d",&y,&x,&y1,&x1);
				tb=((betb=clock())-startb)/10;
				getchar();
				a[x1-1][y1-'a']=con;
				fprintf(fp,"%c%d\n",y1,x1);
				graph(a);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			}
			else
			{
				scanf("%d",&x);
				fprintf(fp,"%c%d\n",begin1,x);
				getchar();
				tb=((betb=clock())-startb)/10;
				a[x-1][begin1-'a']=con;
				graph(a);
				printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			}
			x1=0;
			while(x1==0)
			{
				con=(-1)*con;
				startw = clock();
				search2(a,b1,1);
				search2(a,b2,-1);
				score(b1,b2,c,con);
				compare(c,d);
				a[d[0]][d[1]]=con;
				printf("%d%d\n",d[0],d[1]);
				tw=((betw=clock())-startw)/10;
				y=d[1]+'a';
				fprintf(fp,"%c%d\n",y,d[0]+1);
				graph(a);
				printf("\nthe last chess is %c%d\n",y,d[0]+1);
				printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
				x1=judge2(a);
				if(x1==0)
				{
					con=(-1)*con;
					startb = clock();
					scanf("%c%d",&y,&x);
					fprintf(fp,"%c%d\n",y,x);
					getchar();
					tb=((betb=clock())-startb)/10;
					a[x-1][y-'a']=con;
					graph(a);
					printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
					x1=judge3(a);
				}
			}
		}
		else
		{
			fprintf(fp,"%c%d\n",y,x);
			a[(x-1)][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
			startb = clock();
			search2(a,b1,con);
			search2(a,b2,(-1)*con);
			score(b1,b2,c,con);
			compare(c,d);
			if(*(argv[1]+2)=='1')
			{
				printf("w%c%d %c%d\n",d[1]+'a',d[0]+1,d[3]+'a',d[2]+1);
				scanf("%d",&x);
				getchar();
				if(x==2)
					d[0]=d[2];d[1]=d[3];
			}
			a[d[0]][d[1]]=con;
			tb=((betb=clock())-startb)/10;
			graph(a);
			y=d[1]+'a';
			fprintf(fp,"%c%d\n",y,d[0]+1);
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			x1=0;
			while(x1==0)
			{
				con=(-1)*con;
				startw = clock();
				scanf("%c%d",&y,&x);
				getchar();
				fprintf(fp,"%c%d\n",y,x);
				tw=((betw=clock())-startw)/10;
				a[x-1][y-'a']=con;
				graph(a);
				printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
				x1=judge2(a);
				if(x1==0)
				{
					con=(-1)*con;
					search2(a,b1,con);
					search2(a,b2,(-1)*con);
					score(b1,b2,c,con);
					compare(c,d);
					if(c[d[0]][d[1]]>=0)
					{
						a[d[0]][d[1]]=con;
						tw=((betw=clock())-startw)/10;
						y=d[1]+'a';
						fprintf(fp,"%c%d\n",y,d[0]+1);
						graph(a);
						printf("\nthe last chess is %c%d\n",y,d[0]+1);
						printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
						x1=judge3(a);
					}
					else
						printf("\npass\n");
						fprintf(fp,"%c%d\n",'h',20);
				}
			}
		}
		if(x1<0)
			printf("\nblack is winner");
		else if(x1>0)
			printf("\nwhite is winner");
		fclose(fp);
	}
	
	else if(*argv[1]=='j'&&*(argv[1]+1)=='b'&&*(argv[1]+2)=='j'&&argc!=4)
	{
		int js[15][15],b1[15][15][6],b2[15][15][6],c[15][15],d[8];
		int x1;char y1;
		if(argc==3)
		{
			name=argv[2];
		}
		else
			name="zbc";
		fp=fopen(name,"w");
		startb = clock();
		open=getchar();
		if(open=='z')
		{
			scanf("%c%d",&begin1,&begin2);
			getchar();
			tb=((betb=clock())-startb)/10;
			printf("black's time:%2.1fs\nwhite's time:0.0\n",tb);
			kaiju(a,begin1,begin2);
			graph(a);
			fprintf(fp,"%c%c%d\n",open,begin1,begin2);
			con=(-1)*con;
			startw = clock();
		}
		else
		{
			scanf("%d",&x);
			fprintf(fp,"%c%d\n",open,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][open-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%2.1fs\nwhite's time:0.0\n",tb);
			startw = clock();
			a[x][open-'a'+1]=con;
			graph(a);
			fprintf(fp,"%c%d\n",open+1,x+1);
			tw=((betw=clock())-startw)/10;
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			con=(-1)*con;
			startb = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			startw = clock();
		}
		jinshou(a,js);
		search1(a,b1,1);
		search1(a,b2,-1);
		score2(b1,b2,js,c,con);
		compare(c,d);
		a[d[0]][d[1]]=con;
		printf("%d%d\n",d[0],d[1]);
		tw=((betw=clock())-startw)/10;
		y=d[1]+'a';
		fprintf(fp,"%c%d\n",y,d[0]+1);
		graph(a);
		printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
		con=(-1)*con;
		startb = clock();
		begin1=getchar();
		if(begin1=='w')
		{
			scanf("%c%d %c%d",&y,&x,&y1,&x1);
			tb=((betb=clock())-startb)/10;
			getchar();
			a[x1-1][y1-'a']=con;
			fprintf(fp,"%c%d\n",y1,x1);
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		else
		{
			scanf("%d",&x);
			fprintf(fp,"%c%d\n",begin1,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][begin1-'a']=con;
			graph(a);
			printf("black's time:%.1fs\nwhite's time:%.1fs\n",tb,tw);
		}
		x1=0;
		while(x1==0)
		{
			con=(-1)*con;
			startw = clock();
			jinshou(a,js);
			search1(a,b1,1);
			search1(a,b2,-1);
			score2(b1,b2,js,c,con);
			compare(c,d);
			if(c[d[0]][d[1]]>=0)
			{
				a[d[0]][d[1]]=con;
				tw=((betw=clock())-startw)/10;
				y=d[1]+'a';
				fprintf(fp,"%c%d\n",y,d[0]+1);
				graph(a);
				printf("\nthe last chess is %c%d\n",y,d[0]+1);
				printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
				x1=judge2(a);
			}
			else
				printf("\npass\n");
				fprintf(fp,"%c%d\n",'h',20);
			if(x1==0)
			{
				jinshou(a,js);
				con=(-1)*con;
				startb = clock();
				scanf("%c%d",&y,&x);
				fprintf(fp,"%c%d\n",y,x);
				getchar();
				tb=((betb=clock())-startb)/10;
				a[x-1][y-'a']=con;
				graph(a);
				printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
				x1=judge3(a);
				
				x1+=wjr(js,x-1,y-'a');
			}
		}
	if(x1<0)
		printf("\nblack is winner");
	else if(x1>0)
		printf("\nwhite is winner");
		//fprintf(fp,"%d骞?d鏈?d鏃?d鐐?d鍒哱n",
		//local->tm_year+1900,local->tm_mon+1,local->tm_mday;
		//local->tm_hour,local->tm_min);
		fclose(fp);
	}
	
	else if(*argv[1]=='j'&&*(argv[1]+1)=='b'&&argc!=4)
	{
		int b1[15][15][6],b2[15][15][6],c[15][15],d[8];
		int x1;char y1;
		if(argc==3)
		{
			name=argv[2];
		}
		else
			name="zbc";
		fp=fopen(name,"w");
		startb = clock();
		open=getchar();
		if(open=='z')
		{
			scanf("%c%d",&begin1,&begin2);
			getchar();
			tb=((betb=clock())-startb)/10;
			printf("black's time:%2.1fs\nwhite's time:0.0\n",tb);
			kaiju(a,begin1,begin2);
			graph(a);
			fprintf(fp,"%c%c%d\n",open,begin1,begin2);
			con=(-1)*con;
			startw = clock();
		}
		else
		{
			scanf("%d",&x);
			fprintf(fp,"%c%d\n",open,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][open-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%2.1fs\nwhite's time:0.0\n",tb);
			startw = clock();
			a[x][open-'a'+1]=con;
			graph(a);
			fprintf(fp,"%c%d\n",open+1,x+1);
			tw=((betw=clock())-startw)/10;
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			con=(-1)*con;
			startb = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tb=((betb=clock())-startb)/10;
			a[x-1][y-'a']=con;
			con=(-1)*con;
			graph(a);
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			startw = clock();
		}
		//begin jiaohuan
		temp=tb;
		tb=tw;
		tw=temp;
		printf("black and white have changed\nblack's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
		startw = clock();
		scanf("%c%d",&y,&x);
		fprintf(fp,"%c%d\n",y,x);
		getchar();
		tw=((betw=clock())-startw)/10;
		a[x-1][y-'a']=con;
		con=(-1)*con;
		graph(a);
		printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
		
		startb = clock();
		search2(a,b1,con);
		search2(a,b2,(-1)*con);
		score(b1,b2,c,con);
		compare(c,d);
		if(*(argv[1]+2)=='1')
		{
			printf("w%c%d %c%d\n",d[1]+'a',d[0]+1,d[3]+'a',d[2]+1);
			scanf("%d",&x);
			getchar();
			if(x==2)
				d[0]=d[2];d[1]=d[3];
		}
		a[d[0]][d[1]]=con;
		tb=((betb=clock())-startb)/10;
		graph(a);
		printf("%d%d\n",d[0],d[1]);
		y=d[1]+'a';
		fprintf(fp,"%c%d\n",y,d[0]+1);
		printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
		x1=0;
		while(x1==0)
		{
			con=(-1)*con;
			startw = clock();
			scanf("%c%d",&y,&x);
			fprintf(fp,"%c%d\n",y,x);
			getchar();
			tw=((betw=clock())-startw)/10;
			a[x-1][y-'a']=con;
			graph(a);
			printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
			x1=judge2(a);
			if(x1==0)
			{
				con=(-1)*con;
				startb = clock();
				search2(a,b1,con);
				search2(a,b2,(-1)*con);
				score(b1,b2,c,con);
				compare(c,d);
				a[d[0]][d[1]]=con;
				tb=((betb=clock())-startb)/10;
				y=d[1]+'a';
				fprintf(fp,"%c%d\n",y,d[0]+1);
				graph(a);
				printf("\nthe last chess is %c%d\n",y,d[0]+1);
				printf("black's time:%2.1fs\nwhite's time:%2.1fs\n",tb,tw);
				x1=judge3(a);
			}
		}
		if(x1<0)
			printf("\nblack is winner");
		else if(x1>0)
			printf("\nwhite is winner");
		//fprintf(fp,"%d骞?d鏈?d鏃?d鐐?d鍒哱n",
		//local->tm_year+1900,local->tm_mon+1,local->tm_mday;
		//local->tm_hour,local->tm_min);
		fclose(fp);
	}
	else if(*argv[1]=='d')
	{
		name=argv[2];
		fp=fopen(name,"r");
		struct ywy{
			char y1;
			int x1;
			char y2;
		}zcq[225];
		y=0;
		x=0;
		if((zcq[x].y1=fgetc(fp))=='z')
		{
			fscanf(fp,"%c%d",&zcq[y].y1,&zcq[y].x1);
			kaiju(a,zcq[y].y1,zcq[y].x1);
			graph(a);
			con=(-1)*con;
			x++;
		}
		else
		{
			fscanf(fp,"%d",&zcq[y].x1);
			a[zcq[y].x1-1][zcq[y].y1-'a']=con;
			graph(a);
			con=(-1)*con;
			x++;
		}
		while(fscanf(fp," %c%d",&zcq[x].y1,&zcq[x].x1)==2)
		{
			x++;/*to read the total amount*/
		}
		x--;
		while(1)
		{
			scanf("%d",&i);
			getchar();
			if(i==2&&y<=x)
			{
				y++;/*to count*/
				if(zcq[y].x1=='h'&&zcq[y].y1=='h')
				printf("black and white have exchanged");
				else 
				{
					if(zcq[y].x1<=15)
					{
						a[zcq[y].x1-1][zcq[y].y1-'a']=con;
						graph(a);
						con=(-1)*con;
					}
				}
			}
			else if(i==1&&y>1)
			{
				if(zcq[y].x1=='h'&&zcq[y].y1=='h')
					printf("black and white have exchanged");
				else 
				{
					if(zcq[y].x1<=15)
					{
						a[zcq[y].x1-1][zcq[y].y1-'a']=0;
						con=(-1)*con;
						graph(a);
					}
				}
				y--;
			}
		}
	}
}
